package com.example.prog5;

import android.content.Intent;
import android.os.Bundle;

import com.google.android.material.snackbar.Snackbar;

import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.TextView;
import android.widget.Toast;

import androidx.navigation.NavController;
import androidx.navigation.Navigation;
import androidx.navigation.ui.AppBarConfiguration;
import androidx.navigation.ui.NavigationUI;

import com.example.prog5.databinding.ActivityUserLoginBinding;

public class UserLogin extends AppCompatActivity {
TextView tv;
Button btn;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        tv=findViewById(R.id.loginuser);
        btn=findViewById(R.id.logout);
        Intent i = getIntent();
        String username = i.getStringExtra("name").toString();
        tv.setText("Hello "+ username);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent im = new Intent(UserLogin.this,MainActivity.class);
                Toast.makeText(UserLogin.this,"Logout Successfully",Toast.LENGTH_SHORT).show();
                startActivity(im);
            }
        });

    }
}