package com.example.prog5;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;
import android.util.Log;

import androidx.annotation.Nullable;
import java.io.Serializable;
public class database extends SQLiteOpenHelper {

    public database(Context context, @Nullable String name,@Nullable SQLiteDatabase.CursorFactory factory, int version) {
        super(context, name,factory,version);

    }

    @Override
    public void onCreate(SQLiteDatabase sqLiteDatabase) {
        sqLiteDatabase.execSQL("create table user(username text,password text)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase sqLiteDatabase, int i, int i1) {
        sqLiteDatabase.execSQL("drop table if exists user");

    }
    public void insertdata(String Username,String Password){
        //SQLiteDatabase db=this.getWritableDatabase();
        ContentValues contentValues =new ContentValues();
        contentValues.put("username",Username);
        contentValues.put("password",Password);
        this.getWritableDatabase().insert("user",null, contentValues);
        this.close();
    }
    public boolean getData(String Username, String Password){
        String[] args = new String[]{Username,Password};
        Cursor cr=this.getWritableDatabase().query("user",new String[]{"username","password"},"username = ? and password = ?", new String[]{Username,Password},null,null,null);
        Log.d("set username = ", Username);
        Log.d("set password = ", Password);
        return cr.moveToNext();

    }
}
