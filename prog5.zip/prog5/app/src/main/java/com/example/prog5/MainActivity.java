package com.example.prog5;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.database.sqlite.SQLiteOpenHelper;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;

public class MainActivity extends AppCompatActivity implements Serializable {
    EditText username,password;
    Button login,register;
    database db=new database(MainActivity.this,"user" , null,1);
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        username=findViewById(R.id.newuser);
        password=findViewById(R.id.newpassword);
        login=findViewById(R.id.loginbtn);
        register=findViewById(R.id.registerbtn);

        register.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.insertdata(username.getText().toString(),password.getText().toString());
                Toast.makeText(MainActivity.this,"Registered Successfully",Toast.LENGTH_SHORT).show();
                Log.d("username = ", username.getText().toString());
                Log.d("password = ", password.getText().toString());
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                db.getData(username.getText().toString(),password.getText().toString());

                Toast.makeText(MainActivity.this,"Login Successfully",Toast.LENGTH_SHORT).show();
//                Intent secondlogin = new Intent(MainActivity.this,UserLogin.class);
//                String users= username.getText().toString();
//                secondlogin.putExtra("name",users);
//                startActivity(secondlogin);
                Log.d("set username = ", username.getText().toString());
                Log.d("set password = ", password.getText().toString());
            }
        });


    }
}