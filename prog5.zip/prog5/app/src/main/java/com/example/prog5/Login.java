package com.example.prog5;

import android.content.Intent;
import android.os.Bundle;



import androidx.appcompat.app.AppCompatActivity;

import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import java.io.Serializable;


public class Login extends AppCompatActivity implements Serializable  {
    database db=new database(Login.this,"user" , null,1);
    EditText username,pass;
    Button btn;
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        username=findViewById(R.id.user);
        pass=findViewById(R.id.password);
        btn=findViewById(R.id.login);
        btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                db.getData(username.getText().toString(),pass.getText().toString());
                Intent i =new Intent(Login.this,UserLogin.class);
                i.putExtra("name",username.getText().toString());
                Toast.makeText(Login.this,"Login Successfully",Toast.LENGTH_SHORT).show();
                startActivity(i);
            }
        });
    }

}